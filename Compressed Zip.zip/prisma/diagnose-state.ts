/**
 * READ-ONLY diagnosis. Prints the current database state for (1) Physical
 * Chemistry quizzes and (2) Medical School books + their disciplines, so we can
 * see exactly why something isn't showing. Writes ./diagnose-state.txt too.
 * Changes nothing.
 */
import { PrismaClient } from "@prisma/client";
import * as fs from "fs";

async function main() {
  const p = new PrismaClient();
  const out: string[] = [];
  const log = (s = "") => { out.push(s); console.log(s); };
  try {
    log("===== PHYSICAL CHEMISTRY QUIZZES =====");
    const qs = await p.quiz.findMany({
      where: { slug: { startsWith: "physical-chemistry" } },
      select: { slug: true, kind: true, published: true, order: true, _count: { select: { questions: true } } },
      orderBy: [{ kind: "asc" }, { order: "asc" }],
    });
    if (!qs.length) log("  (none found — the Physical Chemistry seed has not written to THIS database)");
    for (const q of qs) {
      log(`  ${q.published ? "published" : "UNPUBLISHED"}  ${q.kind.padEnd(8)} order ${String(q.order).padEnd(3)} ${q.slug}  — ${q._count.questions} questions`);
    }
    log(`  total: ${qs.length} Physical Chemistry quizzes`);
    const hasSet3 = qs.some((q: { slug: string }) => q.slug === "physical-chemistry-practice-set-3");
    const hasSet4 = qs.some((q: { slug: string }) => q.slug === "physical-chemistry-practice-set-4");
    const hasExam2 = qs.some((q: { slug: string }) => q.slug === "physical-chemistry-exam-2");
    log(`  Set 3 present: ${hasSet3}   Set 4 present: ${hasSet4}   Exam 2 present: ${hasExam2}`);

    log("");
    log("===== BOOKS BY CATEGORY =====");
    const cats = await p.book.groupBy({ by: ["category"], _count: { _all: true } });
    cats.forEach((c: any) => log(`  ${String(c.category).padEnd(24)} ${c._count._all}`));

    log("");
    log("===== MEDICAL SCHOOL BOOKS — DISCIPLINES =====");
    try {
      const med = await p.book.findMany({
        where: { category: "MEDICAL_SCHOOL_BOOKS" as any },
        select: { title: true, published: true, discipline: true } as any,
      }) as Array<{ title: string; published: boolean; discipline: string | null }>;
      log(`  MEDICAL_SCHOOL_BOOKS: ${med.length} total (${med.filter((b) => b.published).length} published)`);
      const by: Record<string, number> = {};
      for (const b of med) { const d = b.discipline ?? "(none set)"; by[d] = (by[d] || 0) + 1; }
      Object.entries(by).sort().forEach(([k, v]) => log(`     ${k.padEnd(26)} ${v}`));
      const withDisc = med.filter((b) => b.discipline).length;
      log(`  books with a discipline set: ${withDisc} of ${med.length}`);
    } catch (e: any) {
      log("  ✗ Could not read `discipline` — the column may not exist yet.");
      log("    Message: " + e.message);
      log("    Fix: run `npx prisma db push` then `npx prisma generate`.");
    }

    fs.writeFileSync("diagnose-state.txt", out.join("\n"), "utf8");
    console.log("\nWrote diagnose-state.txt — paste it (or the console output above) back.");
  } finally {
    await p.$disconnect();
  }
}
main().catch((e) => { console.error("FAILED:", e); process.exit(1); });
