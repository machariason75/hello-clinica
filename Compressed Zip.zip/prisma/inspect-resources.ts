/**
 * READ-ONLY diagnostic — does NOT change anything.
 *
 * Lists every Free Resource with its stored category, published flag, and
 * (if present) archived flag, so we can see whether items you "moved" actually
 * carry the new category value in the database and whether the client would
 * ever query for that value.
 *
 * Run:   npx tsx prisma/inspect-resources.ts
 * Output: prints to the screen AND writes  resources-db.txt  to the project root.
 *
 * This is a LOCAL tool. Do NOT commit it (it is added to .gitignore in the
 * instructions so it can never break the Vercel build).
 */
import { PrismaClient } from "@prisma/client";
import { writeFileSync } from "fs";

const prisma = new PrismaClient();

async function main() {
  const out: string[] = [];
  const log = (s = "") => out.push(s);

  const rows: any[] = await (prisma as any).resource.findMany({
    orderBy: [{ category: "asc" }, { title: "asc" }],
  });

  log(`TOTAL resources in database: ${rows.length}`);
  log("");

  // Reveal the REAL field names on a Resource row (so the fix targets the right fields)
  if (rows[0]) {
    log("FIELDS PRESENT ON A RESOURCE ROW:");
    log("  " + Object.keys(rows[0]).join(", "));
    log("");
  }

  // Group by whatever the category field holds
  const byCat: Record<string, any[]> = {};
  for (const r of rows) {
    const c = String(r.category ?? r.resourceCategory ?? "(no category field found)");
    (byCat[c] ||= []).push(r);
  }

  log("=== COUNT BY CATEGORY  (published / unpublished / archived) ===");
  for (const c of Object.keys(byCat).sort()) {
    const list = byCat[c];
    const pub = list.filter((r) => r.published).length;
    const unpub = list.filter((r) => !r.published).length;
    const arch = list.filter((r) => r.archived).length;
    log(`${c}:  total ${list.length}  |  published ${pub}  |  unpublished ${unpub}  |  archived ${arch}`);
  }
  log("");

  log("=== EVERY RESOURCE  (id | category | published | archived | title) ===");
  for (const c of Object.keys(byCat).sort()) {
    log("");
    log(`-- ${c} --`);
    for (const r of byCat[c]) {
      const cat = r.category ?? r.resourceCategory ?? "?";
      const arch = r.archived === undefined ? "n/a" : r.archived;
      log(`${r.id} | ${cat} | pub=${r.published} | arch=${arch} | ${r.title}`);
    }
  }

  const text = out.join("\n");
  console.log(text);
  writeFileSync("resources-db.txt", text, "utf8");
  console.log("\n\nWrote resources-db.txt to the project root. Please upload that file.");
}

main()
  .catch((e) => {
    console.error("Inspector error:", e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
