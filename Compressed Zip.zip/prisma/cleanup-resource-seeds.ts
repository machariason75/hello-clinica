/**
 * OPTIONAL, SAFE cleanup of SEEDED resource scaffolding.
 *
 * Removes only the auto-seeded placeholder content so each Free Resources
 * category shows just the documents you actually uploaded:
 *
 *   1) Nursing sub-folder seed items   — id starts with "seed-nrs-"        (42)
 *   2) Placeholder document pairs      — id starts with "cmqssatnd" AND the
 *      title ends with ": Getting Started Guide" or ": Checklist & Templates" (18)
 *
 * It matches on BOTH the seed id-prefix AND (for the pairs) the title, so a real
 * upload can never be caught by accident. Your genuine uploads — the 63 nursing
 * documents and everything in Study Resources / Admissions / etc. — are left alone.
 *
 * SAFETY:
 *   • DRY RUN by default — prints exactly what WOULD be deleted, deletes nothing.
 *   • To actually delete, set  CONFIRM_DELETE=YES  — it first writes a full
 *     backup to  resource-seeds-backup.json  so anything removed can be restored.
 *
 * Run (preview):   npx tsx prisma/cleanup-resource-seeds.ts
 * Run (apply):     CONFIRM_DELETE=YES npx tsx prisma/cleanup-resource-seeds.ts
 *
 * LOCAL TOOL — do NOT commit it (the instructions add it to .gitignore so it
 * can never break the Vercel build).
 */
import { PrismaClient } from "@prisma/client";
import { writeFileSync } from "fs";

const prisma = new PrismaClient();
const APPLY = process.env.CONFIRM_DELETE === "YES";

type Row = { id: string; title: string; category: string; published: boolean };

function seedReason(r: Row): string | null {
  if (r.id.startsWith("seed-nrs-")) return "nursing sub-folder seed";
  if (
    r.id.startsWith("cmqssatnd") &&
    (/:\s*Getting Started Guide\s*$/.test(r.title) || /:\s*Checklist & Templates\s*$/.test(r.title))
  ) {
    return "placeholder pair";
  }
  return null;
}

async function main() {
  const rows: Row[] = await (prisma as any).resource.findMany({
    orderBy: [{ category: "asc" }, { title: "asc" }],
  });

  const targets = rows
    .map((r) => ({ row: r, why: seedReason(r) }))
    .filter((t): t is { row: Row; why: string } => t.why !== null);

  console.log(`Scanned ${rows.length} resources.`);
  console.log(`Seeded scaffolding matched: ${targets.length}\n`);

  // Group the matches by category for a readable summary
  const byCat = new Map<string, { row: Row; why: string }[]>();
  for (const t of targets) {
    const list = byCat.get(t.row.category) ?? [];
    list.push(t);
    byCat.set(t.row.category, list);
  }
  for (const cat of [...byCat.keys()].sort()) {
    const list = byCat.get(cat)!;
    console.log(`-- ${cat}  (${list.length} to remove) --`);
    for (const t of list) console.log(`   [${t.why}] ${t.row.title}`);
  }

  // Show what each category is LEFT with, so you can confirm nothing real goes
  const survivorsByCat = new Map<string, number>();
  const targetIds = new Set(targets.map((t) => t.row.id));
  for (const r of rows) {
    if (targetIds.has(r.id)) continue;
    survivorsByCat.set(r.category, (survivorsByCat.get(r.category) ?? 0) + 1);
  }
  console.log(`\n=== Remaining (real) resources per category after cleanup ===`);
  for (const cat of [...new Set(rows.map((r) => r.category))].sort()) {
    console.log(`   ${cat}: ${survivorsByCat.get(cat) ?? 0}`);
  }

  if (!APPLY) {
    console.log(
      `\nDRY RUN — nothing was deleted. ${targets.length} items would be removed.` +
        `\nRe-run with  CONFIRM_DELETE=YES  to apply (a backup file is written first).`
    );
    return;
  }

  writeFileSync("resource-seeds-backup.json", JSON.stringify(targets.map((t) => t.row), null, 2), "utf8");
  console.log(`\nWrote backup: resource-seeds-backup.json (${targets.length} rows).`);

  const result = await (prisma as any).resource.deleteMany({
    where: { id: { in: [...targetIds] } },
  });
  console.log(`Deleted ${result.count} seeded resources. Real uploads untouched.`);
}

main()
  .catch((e) => {
    console.error("Cleanup error:", e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
